@extends('layouts.app')
@section('content')
@section('page_css')
    <link rel="stylesheet" href="{{ asset('assets/css/int-tel/css/intlTelInput.css') }}">
@endsection
@section('header_toolbar')
    <div class="toolbar" id="kt_toolbar">
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                 data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                 class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                <h1 class="d-flex align-items-center text-dark fw-bolder fs-3 my-1">TPA Master</h1>
            </div>
            <div class="d-flex align-items-center py-1">
                <a href="{{ route('tpamaster.index') }}"
                   class="btn btn-sm btn-light btn-active-light-primary pull-right">{{ __('messages.common.back') }}</a>
            </div>
        </div>
    </div>
@endsection
<div class="card">
  <div class="card-body">
      <form action="{{ url('tpamaster') }}" method="post">
        {!! csrf_field() !!}
        <div class="form-group row">
            <div class="col-sm-5">
                    <label class="col-form-label">Payment Mode</label>
                    <select id="tpapaymentmode" name="tpapaymentmode" class="form-control">
                    <option value="">--Select Payment Mode--</option>
                    @foreach( $pharamaone as $items)
                        <option value="{{ $items->id }}">{{ $items->paymentmode}}</option>
                    @endforeach
                    </select>
                </div>  
                <div class="col-sm-5">                                   
                    <label class="col-form-label">Payment Type</label>
                    <input type="text" name="tpapaymenttype" id="tpapaymenttype" class="form-control">
                </div>
        </div><br><br>
        <div align="center" class="col-sm-10">
            <input type="submit" value="Save" class="btn btn-success">
        </div>

<script>
$(document).ready(function(){
 $('.selectpicker').selectpicker();

 $('#framework').change(function(){
  $('#hidden_framework').val($('#framework').val());
 });
  
 });

</script>
    </form>
  </div>
</div> 
@stop