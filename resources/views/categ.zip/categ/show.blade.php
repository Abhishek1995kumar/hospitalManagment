@extends('categ.layout')
@section('content')
 
 
<div class="card">
  <div class="card-header">Contactus Page</div>
  <div class="card-body">
   
 
        <div class="card-body">
        <h5 class="card-title">Category Name : {{ $categ->category_name }}</h5>
  </div>
       
    </hr>
  
  </div>
</div>