@extends('layouts.app')
@section('title')
    {{ __('Add Location Master') }}
    @endsection
@section('page_css')
    <link rel="stylesheet" href="{{ asset('assets/css/int-tel/css/intlTelInput.css') }}">
@endsection
@section('header_toolbar')
    <div class="toolbar" id="kt_toolbar">
        <div id="kt_toolbar_container" class="container-fluid d-flex flex-stack">
            <div data-kt-swapper="true" data-kt-swapper-mode="prepend"
                 data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                 class="page-title d-flex align-items-center flex-wrap me-3 mb-5 mb-lg-0">
                <h1 class="d-flex align-items-center text-dark fw-bolder fs-3 my-1">@yield('title')</h1>
            </div>
            <div class="d-flex align-items-center py-1">
                <a href="{{ route('location') }}"
                   class="btn btn-sm btn-light btn-active-light-primary pull-right">{{ __('messages.common.back') }}</a>
            </div>
        </div>
    </div>
@endsection
@section('content')
    <div class="d-flex flex-column flex-lg-row">
        <div class="flex-lg-row-fluid mb-10 mb-lg-0 me-lg-7 me-xl-10">
            <div class="row">
                <div class="col-12">
                    @include('layouts.errors')
                </div>
               
                

            </div>
           
            <div class="card">
                <div class="card-body p-12">
                    
                <form action="{{url('location/add')}}" method="post" id="addlocation" name="addlocation">
                    @csrf
            <div class="form-group row">
          <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Location Name:</label>
            <input type="text" name="lname" id="lname" class="form-control form-control-solid" placeholder="Enter location" required>
          </div>
           <div class="col-sm-3">
           <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Alternate Location Name:</label>
            <input type="text" name="alname" id="alname" placeholder="Enter Alternate location" class="form-control form-control-solid" required>
          </div>
           <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Specialization:</label>
            <input type="text" name="specialization" id="specialization"   placeholder="Enter Specialization" class="form-control form-control-solid" required>
          </div> 
          <div class="col-sm-3">
          <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Constitution:</label>
          <input type="text" name="constitution" id="constitution"  placeholder="Enter Constitution"  class="form-control form-control-solid" required> 
        </div>
        </div></br>
       <div class="form-group row">
          <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Mobile:</label>
            <input type="number" name="mobile" id="mobile" placeholder="Enter Mobile"  class="form-control form-control-solid" required>
          </div>
           <div class="col-sm-3">
          <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Email:</label>
            <input type="email" name="email" id="email" placeholder="Enter Email" class="form-control form-control-solid" required>
          </div>
           <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Phone No:</label>
            <input type="number" name="phone" id="phone"  placeholder=" Enter Phone No" class="form-control form-control-solid" required>
          </div> 
          <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Fax No:</label>
            <input type="text" name="fax_no" id="fax_no" placeholder="Enter Fax No" class="form-control form-control-solid" required>
        </div> 
        </div><br>
        <div class="form-group row">
          <div class="col-sm-3">
         <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Building:</label>
            <input type="text" name="building" id="building" placeholder="Enter Building" class="form-control form-control-solid" required>
          </div>
           <div class="col-sm-3">
             <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Street:</label>
            <input type="text" name="street" id="street" placeholder="Enter Street" class="form-control form-control-solid" required>
          </div>
           <div class="col-sm-3">
              <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Suburb:</label>
            <input type="text" name="suburb" id="suburb" placeholder="Enter Suburb" class="form-control form-control-solid" required>
          </div>
          <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Zip Code:</label>
            <input type="text" name="zip_code" id="zip_code" placeholder="Enter Zip Code" class="form-control form-control-solid" required>
        </div>
        </div><br>

        <div class="form-group row">
          <div class="col-sm-3">
             <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">GST No:</label>
            <input type="text" name="gst" id="gst"  placeholder="Enter GST No" class="form-control form-control-solid" required>
          </div>
          <div class="col-sm-3">
             
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Country</label>
            <select  id="country" name="country" class="form-control form-control-solid" required>
            <option value="">Select Country</option>
                @foreach ($data as $val)
                <option value="{{$val->id}}">
                    {{$val->name}}
                </option>
                @endforeach
            </select>
          </div>
          <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">State</label>
            <select id="state" name="state" class="form-control form-control-solid">
            </select>
        </div>
        <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">City</label>
            <select id="city" name="city" class="form-control form-control-solid">
            </select>
        </div>
        </div> <br>
        <div class="form-group row">
          <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Bill No.Prefix:</label>
            <input type="text" name="bill_no_prefix" placeholder="Enter Bill No.Prefix" id="bill_no_prefix" class="form-control form-control-solid" required>
        </div>
        <div class="col-sm-3">
            <label class="form-label fs-6 fw-bolder text-gray-700 mb-3">Drug & Lic. No:</label>
            <input type="area" name="drug_lic_no" placeholder="Enter Drug & Lic.No:" id="user_id" class="form-control form-control-solid" required>
        </div>
        </div><br>
        <div align="center">
       <input type="submit" value="Save" class="btn btn-success" id="submitdt"></br>
       </div>
    </form>
   

</div>
 
@stop

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#country').on('change', function () {
                // alert("hii");die();
                var idCountry = this.value;
                $("#state").html('');
                $.ajax({
                    url: "{{url('/fetchState')}}",
                    type: "GET",
                    data: {
                        country_id: idCountry,
                        _token: '{{csrf_token()}}'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#state').html('<option value="">Select State</option>');
                        $.each(result, function (key, value) {
                            $("#state").append('<option value="' +key + '">' + value + '</option>');
                        });
                        $('#city').html('<option value="">Select City</option>');
                    }
                });
            });
            $('#state').on('change', function () {
                // alert("hii");die();
                var idState = this.value;
                $("#city").html('');
                $.ajax({
                    url: "{{url('/fetchCity')}}",
                    type: "GET",
                    data: {
                        state_id: idState,
                        _token: '{{csrf_token()}}'
                    },
                    dataType: 'json',
                    success: function (res) {
                        $('#city').html('<option value="">Select City</option>');
                        $.each(res, function (key, value) {
                            $("#city").append('<option value="' + key + '">' + value + '</option>');
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>
