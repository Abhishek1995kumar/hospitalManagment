<html>
<head>
<style>
table{
width: 100%;
/*border-collapse:0;*/
border: 1px solid black;
}
table td{line-height:20px;padding-left:15px;}
table th{color:#363636; text-align: center;}
.image {
        width: 150px;
        height: 50px;
        /*border-radius: 50%;*/
      }
</style>

</head>
<body>

<table>

<br>
<tr height="30px" style="background-color:MediumSeaGreen;color:#ffffff;text-align:center;font-size:20px; font-weight:500;">
<td colspan='6'><img src = assets/img/logo-red-black.png style="margin-top:2rem;"></td>

</tr>
<tr style="background-color:MediumSeaGreen;"><td colspan='6' style="text-align:center"><b>HMS PVT.LTD.</b></td></tr>
</table>

<br><br>
<table>
  <tr height="30px" style="background-color: powderblue;">
  <td colspan="4" style="text-align:center;font-weight:bold;">Salary Slip</td>
  <td colspan="2" style="text-align:center;font-weight:bold;">Month</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
  <td colspan="2" style="font-weight:bold;">Employee code: &nbsp;&nbsp;&nbsp;</td>
  <td colspan="2" style="font-weight:bold;">Departmen: &nbsp;&nbsp;&nbsp; </td>
  <td  colspan="2" style="font-weight:bold;">Total Present Day : &nbsp;&nbsp;&nbsp;</td>
</tr>
<tr>
  <td colspan="2" style="font-weight:bold;">Employee Name: &nbsp;&nbsp;&nbsp; </td>
  <td colspan="2" style="font-weight:bold;">Designation: &nbsp;&nbsp;&nbsp; </td>
  <td colspan="2" style="font-weight:bold;">Total Absent Day: &nbsp;&nbsp;&nbsp; </td>
</tr>
<tr><td>&nbsp;</td></tr>
</table>
<br>

<table border="1">
<tr>
  <td><b>Basic:</b></td>
  <td></td>
  <td><b>HRA:</b></td>
  <td></td>
  <td><b>Gross Salary:</td>
  <td></td>
</tr>
<tr>
  <td><b>PF(Employee Contribution):</b></td>
  <td></td>
  <td><b>ESIC:</b></td>
  <td></td>
  <td><b>PT :</b></td>
  <td></td>
</tr>

<tr>
  <td><b>Total Deductions:</b></td>
  <td></td>
  <td><b>Net Salary : </b></td>
  <td></td>
  <td><b>Employer Contribution PF :</b></td>
  <td></td>
</tr>

<tr>
  <td><b>Employer Contribution ESIC :</b></td>
  <td></td>
  <td><b>Mediclaim Benefit : </b></td>
  <td></td>
  <td><b>CTC  :</b></td>
  <td></td>
</tr>

<tr>
 <!--  <td><b>Month : </b></td>
  <td></td> -->
  <td><b>Total Working Days : </b></td>
  <td></td>
  <td><b>Per Day Salary  :</b></td>
  <td></td>
  <td><b>Total Present Day : </b></td>
  <td></td>
</tr>
<tr>
  <!-- <td><b>Total Present Day : </b></td>
  <td></td> -->
  <td><b>Total Absent Day : </b></td>
  <td></td>
  <td><b>Salary  :</b></td>
  <td></td>
   <td><b>conveyance Allowances : </b></td>
  <td> </td>
</tr>

<tr>
 <!--  <td><b>conveyance Allowances : </b></td>
  <td> </td> -->
  <td><b>medical Allowance : </b></td>
  <td></td>
  <td><b>Rent By Company  :</b></td>
  <td></td>
   <td><b>Incentiv & Bonus : </b></td>
  <td></td>
  
</tr>
<!-- <tr>
  <td><b>Incentiv & Bonus : </b></td>
  <td></td>
</tr> -->
<!-- <tr><td>&nbsp;</td></tr> -->
<tr> 
  <td colspan="6" style="background-color:hsla(9, 100%, 64%, 0.5); text-align: center;" ><h4><b>Net Payable :  &nbsp;&nbsp;&nbsp; </b></h4></td>
</tr>
<tr>
  
</tr>

<tr>

<!-- <td>House Rent Allowance</td>
<td></td>
<td>professional tax</td>
<td></td>
</tr>

<tr>
<td>conveyance Allowances</td>
<td></td>
<td>ESIC</td>
<td></td>
</tr>

<tr>
<td>medical Allowance</td>
<td>></td>
<td>Incentive & Bonus</td>
<td></td>
</tr>
<tr>
<td>Gross Earnings</td>
<td></td>
<td>Total Deductions</td>
<td></td>

</tr>
<tr>
<td>NET Pay</td>
<td></td>
<td>CTC</td>
<td></td>
</tr>
</tr> -->

</table>
<!-- <tr>
<th>Employee code:</th>
<td></td>
<th>Name</th>
<td></td>
</tr>
<tr>
<th>Department</th>
<td></td>
<th>Designation</th>
<td></td>
</tr>
<tr>
<th>Total Working Days</th>
<td></td>
<th>No. Of Working Days Attended</th>
<td></td>
</tr>
<tr>
<th>Leaves</th>
<td></td>
<th>Per Day Salary</th>
<td></td>
</tr> -->
<!-- </table> -->
<!-- <tr></tr>
<br/>
<table border="1">
  <tr style="background-color: powderblue;">
  <td colspan="4"><h5 style="text-align:center;font-weight:bold;">This is The Salary Slip Of Month </h5></td>

</tr>
<tr style="background-color:hsla(9, 100%, 64%, 0.5);">
<th> Earnings</th>
<th> Amount</th>
<th> Deductions</th>
<th> Amount</th>
</tr>


<tr>
<td>Basic</td>
<td></td>
<td>provident fund</td>
<td></td>
  </tr>
<tr>

<td>House Rent Allowance</td>
<td></td>
<td>professional tax</td>
<td></td>
</tr>

<tr>
<td>conveyance Allowances</td>
<td></td>
<td>ESIC</td>
<td></td>
</tr>

<tr>
<td>medical Allowance</td>
<td></td>
<td>Incentive & Bonus</td>
<td></td>
</tr>
<tr>
<td>Gross Earnings</td>
<td></td>
<td>Total Deductions</td>
<td></td>

</tr>
<tr>
<td>NET Pay</td>
<td></td>
<td>CTC</td>
<td></td>
</tr>
</tr> -->

</table>
</body>
</html>

